import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    throw UnsupportedError('Only web is supported on Zapp.run.');
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey:            'AIzaSyDAA29TAqIA9TAy18_-ZbKF4GZsdoeW6lM',
    appId:             '1:217454686166:web:d7b6c7d47093b9dc19fe77',
    messagingSenderId: '217454686166',
    projectId:         'todoappsample-9300b',
    authDomain:        'todoappsample-9300b.firebaseapp.com',
    storageBucket:     'todoappsample-9300b.firebasestorage.app',
  );
}